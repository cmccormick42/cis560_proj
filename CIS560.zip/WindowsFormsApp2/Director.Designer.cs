﻿namespace WindowsFormsApp2
{
    partial class Director
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.blabnlagaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uxDepartment = new System.Windows.Forms.ListBox();
            this.uxDepGPAButton = new System.Windows.Forms.Button();
            this.uxDepGPA = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.uxTeacherCountBox = new System.Windows.Forms.TextBox();
            this.uxTeacherCount = new System.Windows.Forms.TextBox();
            this.uxTeacherCountButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.uxTeacherGradeBox = new System.Windows.Forms.TextBox();
            this.uxTeacherGrade = new System.Windows.Forms.TextBox();
            this.uxTeacherGradeButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.uxAddButton = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blabnlagaToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(127, 26);
            // 
            // blabnlagaToolStripMenuItem
            // 
            this.blabnlagaToolStripMenuItem.Name = "blabnlagaToolStripMenuItem";
            this.blabnlagaToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.blabnlagaToolStripMenuItem.Text = "blabnlaga";
            // 
            // uxDepartment
            // 
            this.uxDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDepartment.FormattingEnabled = true;
            this.uxDepartment.ItemHeight = 20;
            this.uxDepartment.Items.AddRange(new object[] {
            "Computer Science",
            "Business",
            "English",
            "History",
            "Math",
            "Arts",
            "Languages",
            "Education",
            "Leadership",
            "Agriculture"});
            this.uxDepartment.Location = new System.Drawing.Point(12, 35);
            this.uxDepartment.Name = "uxDepartment";
            this.uxDepartment.Size = new System.Drawing.Size(211, 24);
            this.uxDepartment.TabIndex = 1;
            // 
            // uxDepGPAButton
            // 
            this.uxDepGPAButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDepGPAButton.Location = new System.Drawing.Point(229, 32);
            this.uxDepGPAButton.Name = "uxDepGPAButton";
            this.uxDepGPAButton.Size = new System.Drawing.Size(268, 33);
            this.uxDepGPAButton.TabIndex = 2;
            this.uxDepGPAButton.Text = "Calculate GPA";
            this.uxDepGPAButton.UseVisualStyleBackColor = true;
            this.uxDepGPAButton.Click += new System.EventHandler(this.uxDepGPAButton_Click);
            // 
            // uxDepGPA
            // 
            this.uxDepGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDepGPA.Location = new System.Drawing.Point(503, 35);
            this.uxDepGPA.Name = "uxDepGPA";
            this.uxDepGPA.ReadOnly = true;
            this.uxDepGPA.Size = new System.Drawing.Size(78, 26);
            this.uxDepGPA.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(245, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Calculate Teacher Student Count";
            // 
            // uxTeacherCountBox
            // 
            this.uxTeacherCountBox.Location = new System.Drawing.Point(12, 94);
            this.uxTeacherCountBox.Name = "uxTeacherCountBox";
            this.uxTeacherCountBox.Size = new System.Drawing.Size(211, 20);
            this.uxTeacherCountBox.TabIndex = 11;
            // 
            // uxTeacherCount
            // 
            this.uxTeacherCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTeacherCount.Location = new System.Drawing.Point(503, 94);
            this.uxTeacherCount.Name = "uxTeacherCount";
            this.uxTeacherCount.ReadOnly = true;
            this.uxTeacherCount.Size = new System.Drawing.Size(78, 26);
            this.uxTeacherCount.TabIndex = 10;
            // 
            // uxTeacherCountButton
            // 
            this.uxTeacherCountButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTeacherCountButton.Location = new System.Drawing.Point(229, 91);
            this.uxTeacherCountButton.Name = "uxTeacherCountButton";
            this.uxTeacherCountButton.Size = new System.Drawing.Size(268, 33);
            this.uxTeacherCountButton.TabIndex = 9;
            this.uxTeacherCountButton.Text = "Calculate Student Count";
            this.uxTeacherCountButton.UseVisualStyleBackColor = true;
            this.uxTeacherCountButton.Click += new System.EventHandler(this.uxTeacherCountButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "Calculate Department GPA";
            // 
            // uxTeacherGradeBox
            // 
            this.uxTeacherGradeBox.Location = new System.Drawing.Point(12, 156);
            this.uxTeacherGradeBox.Name = "uxTeacherGradeBox";
            this.uxTeacherGradeBox.Size = new System.Drawing.Size(211, 20);
            this.uxTeacherGradeBox.TabIndex = 15;
            // 
            // uxTeacherGrade
            // 
            this.uxTeacherGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTeacherGrade.Location = new System.Drawing.Point(503, 156);
            this.uxTeacherGrade.Name = "uxTeacherGrade";
            this.uxTeacherGrade.ReadOnly = true;
            this.uxTeacherGrade.Size = new System.Drawing.Size(78, 26);
            this.uxTeacherGrade.TabIndex = 14;
            // 
            // uxTeacherGradeButton
            // 
            this.uxTeacherGradeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTeacherGradeButton.Location = new System.Drawing.Point(229, 153);
            this.uxTeacherGradeButton.Name = "uxTeacherGradeButton";
            this.uxTeacherGradeButton.Size = new System.Drawing.Size(268, 33);
            this.uxTeacherGradeButton.TabIndex = 13;
            this.uxTeacherGradeButton.Text = "Calculate Grade";
            this.uxTeacherGradeButton.UseVisualStyleBackColor = true;
            this.uxTeacherGradeButton.Click += new System.EventHandler(this.uxTeacherGradeButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Calculate Teacher Average Grade";
            // 
            // uxAddButton
            // 
            this.uxAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxAddButton.Location = new System.Drawing.Point(12, 207);
            this.uxAddButton.Name = "uxAddButton";
            this.uxAddButton.Size = new System.Drawing.Size(580, 160);
            this.uxAddButton.TabIndex = 18;
            this.uxAddButton.Text = "Add Student";
            this.uxAddButton.UseVisualStyleBackColor = true;
            this.uxAddButton.Click += new System.EventHandler(this.uxAddButton_Click);
            // 
            // Director
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 377);
            this.Controls.Add(this.uxAddButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.uxTeacherGradeBox);
            this.Controls.Add(this.uxTeacherGrade);
            this.Controls.Add(this.uxTeacherGradeButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.uxTeacherCountBox);
            this.Controls.Add(this.uxTeacherCount);
            this.Controls.Add(this.uxTeacherCountButton);
            this.Controls.Add(this.uxDepGPA);
            this.Controls.Add(this.uxDepGPAButton);
            this.Controls.Add(this.uxDepartment);
            this.Name = "Director";
            this.Text = "Director";
            this.Load += new System.EventHandler(this.Director_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem blabnlagaToolStripMenuItem;
        private System.Windows.Forms.ListBox uxDepartment;
        private System.Windows.Forms.Button uxDepGPAButton;
        private System.Windows.Forms.TextBox uxDepGPA;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox uxTeacherCountBox;
        private System.Windows.Forms.TextBox uxTeacherCount;
        private System.Windows.Forms.Button uxTeacherCountButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox uxTeacherGradeBox;
        private System.Windows.Forms.TextBox uxTeacherGrade;
        private System.Windows.Forms.Button uxTeacherGradeButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button uxAddButton;
    }
}