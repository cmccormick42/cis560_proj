﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    public partial class uxForm : Form
    {
        public Student StudentForm;
        public Teacher TeacherForm;
        public Director DirectorForm;

        public uxForm()
        {
            InitializeComponent();
        }




        private void uxDirectorButton_Click(object sender, EventArgs e)
        {
            DirectorForm = new Director();
            DirectorForm.ShowDialog();
        }

        private void uxTeacherButton_Click(object sender, EventArgs e)
        {
            if (uxTeacherId.Text == "")
            {
                MessageBox.Show("Please fill out the teacher ID box");
            }
            else
            {
                if (GetTeacher(Convert.ToInt32(uxTeacherId.Text)) == 1)
                {
                    TeacherForm = new Teacher(uxTeacherId.Text);
                    TeacherForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Teacher does not exist");
                }
            }
        }

        public int GetStudent(int i)
        {
            string s = @"Data Source = mssql.cs.ksu.edu; Initial Catalog = justinm1; Integrated Security = True";
            using (SqlConnection Database = new SqlConnection(s))
            {
                using (var command = new SqlCommand("proj4.CheckExistsStudent", Database))
                {
                    Database.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("StudentId", i);
                    var result = command.Parameters.Add("Result", SqlDbType.Int);
                    result.Direction = ParameterDirection.Output;
                    var reader = command.ExecuteReader();
                    var output = result.Value;
                    return Convert.ToInt32(output);
                }
            }
        }
        public int GetTeacher(int i)
        {
            string s = @"Data Source = mssql.cs.ksu.edu; Initial Catalog = justinm1; Integrated Security = True";
            using (SqlConnection Database = new SqlConnection(s))
            {
                using (var command = new SqlCommand("proj4.CheckExistsInstructor", Database))
                {
                    Database.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("InstructorId", i);
                    var result = command.Parameters.Add("Result", SqlDbType.Int);
                    result.Direction = ParameterDirection.Output;
                    var reader = command.ExecuteReader();
                    var output = result.Value;
                    return Convert.ToInt32(output);
                }
            }
        }
        private void uxStudentButton_Click(object sender, EventArgs e)
        {
            // check id
            if (uxStudentId.Text == "")
            {
                MessageBox.Show("Please fill out the student ID box");
            }
            else
            {
                if (GetStudent(Convert.ToInt32(uxStudentId.Text)) == 1)
                {
                    StudentForm = new Student(uxStudentId.Text);
                    StudentForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Student does not exist");
                }
            }
        }
    }
}

