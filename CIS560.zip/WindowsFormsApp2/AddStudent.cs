﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Transactions;
namespace WindowsFormsApp2
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public int AddStudentMethod()
        {
            using (var transaction = new TransactionScope())
            {
                const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("proj4.AddStudent", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("Name", uxName.Text);
                        command.Parameters.AddWithValue("DepartmentId", uxDepartment.Text);
                        command.Parameters.AddWithValue("Gpa", uxGPA.Text);
                        command.Parameters.AddWithValue("Hours", uxHours.Text);
                        transaction.Complete();
                        var param = command.Parameters.Add("StudentId", SqlDbType.Int);
                        param.Direction = ParameterDirection.Output;
                        command.ExecuteNonQuery();
                
                        return Convert.ToInt32(param.Value);
                    }
                }
            }
        }
        private void uxAdd_Click(object sender, EventArgs e)
        {
            if (uxHours.Text == "" || uxGPA.Text == "" || uxDepartment.Text == "" || uxName.Text == "")
            {
                MessageBox.Show("Please fill out all fields");
            }
            else
            {
                int i=AddStudentMethod();
                MessageBox.Show("Student Added with ID of "+i.ToString());
            }

        }
    }
}
