﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

/*
see all assignments for a certain class
grade certain class
assignments that are due on certain days
for a student with a course under a certain grade, list the assignments with the the lowest grade --report
*/
namespace WindowsFormsApp2
{
    public partial class Student : Form
    {
        Output o;
        public List<string> GetStudentAssignments()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetStudentAssignmentsForCourse", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("StudentId", id);
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);
  
                    
                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();

                    while (reader.Read())
                    {
                        assignments.Add(reader.GetString(reader.GetOrdinal("AssignmentName")));
                    }

                    return assignments;
                }
            }
        }
        public List<string> GetAssignmentsDue()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetAssignmentsDueBeforeDay", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("StudentId", id);
                    command.Parameters.AddWithValue("Date", uxDate.Text);


                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();

                    while (reader.Read())
                    {
                        assignments.Add(reader.GetString(reader.GetOrdinal("AssignmentName")));
                    }

                    return assignments;
                }
            }
        }
        public double GetStudentGrade()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetStudentGradeForCourse", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("StudentId", id);
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);


                    var reader = command.ExecuteReader();

                    var assignments = new double();
                    while (reader.Read())
                    {

                        assignments =(reader.GetDouble(reader.GetOrdinal("Grade")));
                    }

                    return assignments;
                }
            }
        }
        string id;
        public Student(string s)
        {
            id = s;
            InitializeComponent();
            GetInfo();
        }
        public void GetInfo()
        {
            List<string> test = new List<string>();
            string s = @"Data Source = mssql.cs.ksu.edu; Initial Catalog = justinm1; Integrated Security = True";
            using (SqlConnection Database = new SqlConnection(s))
            {
                using (var command = new SqlCommand("proj4.ReturnStudent", Database))
                {
                    Database.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("StudentId", id);
                    
                    var reader = command.ExecuteReader();
                    
                    while (reader.Read())
                    {
                      uxName.Text=(reader.GetString(reader.GetOrdinal("Name")));
                      uxHours.Text = (reader.GetInt32(reader.GetOrdinal("Hours")).ToString());
                      uxDepartment.Text = (reader.GetInt32(reader.GetOrdinal("DepartmentId")).ToString());
                        uxID.Text = (reader.GetInt32(reader.GetOrdinal("StudentId")).ToString());
                        uxGpa.Text = ((reader.GetDouble(reader.GetOrdinal("Gpa"))).ToString());


                    }
                }
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void uxAssignment_Click(object sender, EventArgs e)
        {
            if (uxCourse.Text != "")
            {
                o = new Output(GetStudentAssignments());
                o.ShowDialog();
                
            }
            else
            {
                MessageBox.Show("Please enter a course id");
            }
        }

        private void uxGrade_Click(object sender, EventArgs e)
        {
            if (uxCourse.Text != "")
            {
                uxGradeOut.Text = GetStudentGrade().ToString();

            }
            else
            {
                MessageBox.Show("Please enter a course id");
            }
        }

        private void uxDateAssignments_Click(object sender, EventArgs e)
        {
            if (uxDate.Text != "")
            {
                o = new Output(GetAssignmentsDue());
                o.ShowDialog();

            }
            else
            {
                MessageBox.Show("Please enter a course id");
            }
        }
    }
}
