﻿namespace WindowsFormsApp2
{
    partial class uxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxDirectorButton = new System.Windows.Forms.Button();
            this.uxTeacherButton = new System.Windows.Forms.Button();
            this.uxStudentButton = new System.Windows.Forms.Button();
            this.uxTeacherId = new System.Windows.Forms.TextBox();
            this.uxStudentId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // uxDirectorButton
            // 
            this.uxDirectorButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDirectorButton.Location = new System.Drawing.Point(12, 12);
            this.uxDirectorButton.Name = "uxDirectorButton";
            this.uxDirectorButton.Size = new System.Drawing.Size(355, 53);
            this.uxDirectorButton.TabIndex = 1;
            this.uxDirectorButton.Text = "Director";
            this.uxDirectorButton.UseVisualStyleBackColor = true;
            this.uxDirectorButton.Click += new System.EventHandler(this.uxDirectorButton_Click);
            // 
            // uxTeacherButton
            // 
            this.uxTeacherButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTeacherButton.Location = new System.Drawing.Point(12, 98);
            this.uxTeacherButton.Name = "uxTeacherButton";
            this.uxTeacherButton.Size = new System.Drawing.Size(355, 53);
            this.uxTeacherButton.TabIndex = 2;
            this.uxTeacherButton.Text = "Teacher";
            this.uxTeacherButton.UseVisualStyleBackColor = true;
            this.uxTeacherButton.Click += new System.EventHandler(this.uxTeacherButton_Click);
            // 
            // uxStudentButton
            // 
            this.uxStudentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxStudentButton.Location = new System.Drawing.Point(12, 183);
            this.uxStudentButton.Name = "uxStudentButton";
            this.uxStudentButton.Size = new System.Drawing.Size(355, 53);
            this.uxStudentButton.TabIndex = 3;
            this.uxStudentButton.Text = "Student";
            this.uxStudentButton.UseVisualStyleBackColor = true;
            this.uxStudentButton.Click += new System.EventHandler(this.uxStudentButton_Click);
            // 
            // uxTeacherId
            // 
            this.uxTeacherId.Location = new System.Drawing.Point(12, 71);
            this.uxTeacherId.Name = "uxTeacherId";
            this.uxTeacherId.Size = new System.Drawing.Size(100, 20);
            this.uxTeacherId.TabIndex = 4;
            // 
            // uxStudentId
            // 
            this.uxStudentId.Location = new System.Drawing.Point(12, 157);
            this.uxStudentId.Name = "uxStudentId";
            this.uxStudentId.Size = new System.Drawing.Size(100, 20);
            this.uxStudentId.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Teacher ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Student ID";
            // 
            // uxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 252);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.uxStudentId);
            this.Controls.Add(this.uxTeacherId);
            this.Controls.Add(this.uxStudentButton);
            this.Controls.Add(this.uxTeacherButton);
            this.Controls.Add(this.uxDirectorButton);
            this.Name = "uxForm";
            this.Text = "CIS 560";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button uxDirectorButton;
        private System.Windows.Forms.Button uxTeacherButton;
        private System.Windows.Forms.Button uxStudentButton;
        private System.Windows.Forms.TextBox uxTeacherId;
        private System.Windows.Forms.TextBox uxStudentId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

