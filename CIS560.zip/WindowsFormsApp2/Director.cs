﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
average gpa for a department
display each instructors average grade
for each teacher calculate the number of students in their classes --report
add students
*/
namespace WindowsFormsApp2
{
    public partial class Director : Form
    {
        AddStudent addStudent;
        public Director()
        {
            InitializeComponent();
        }

        private void Director_Load(object sender, EventArgs e)
        {

        }

        private void uxDepGPAButton_Click(object sender, EventArgs e)
        {

        }

        private void uxTeacherCountButton_Click(object sender, EventArgs e)
        {

        }

        private void uxTeacherGradeButton_Click(object sender, EventArgs e)
        {

        }

        private void uxAddButton_Click(object sender, EventArgs e)
        {
            addStudent = new AddStudent();
            addStudent.ShowDialog();
        }
    }
}
