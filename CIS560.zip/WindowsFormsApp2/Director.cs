﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
/*
average gpa for a department
display each instructors average grade
for each teacher calculate the number of students in their classes --report
add students
*/
namespace WindowsFormsApp2
{
    public partial class Director : Form
    {
        AddStudent addStudent;
        public Director()
        {
            InitializeComponent();
        }
        public void GetDepartmentGrade()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetDepartmentGpa", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("DepartmentId", uxDepartmentGPA.Text);



                    var reader = command.ExecuteReader();

                    var assignments = new double();
                    while (reader.Read())
                    {

                        assignments = (reader.GetDouble(reader.GetOrdinal("AverageGpa")));
                    }

                    uxDepGPA.Text = assignments.ToString();
                }
            }
        }
        public void GetTeacherGrade()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetInstructorAverageGrade", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("InstructorId", uxTeacherGradeBox.Text);



                    var reader = command.ExecuteReader();

                    var assignments = new double();
                    while (reader.Read())
                    {

                        assignments = (reader.GetDouble(reader.GetOrdinal("AverageGrade")));
                    }

                    uxTeacherGrade.Text = (assignments.ToString("#.##")) + "%";
                }
            }
        }
        public int GetTeacherCount()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetStudentCount", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("IID", uxTeacherCountBox.Text);
                    var reader = command.ExecuteReader();

                    var assignments = new int();
                    while (reader.Read())
                    {

                        assignments = (reader.GetInt32(reader.GetOrdinal("StudentCount")));
                    }

                    return assignments;
                }
            }
        }
        private void Director_Load(object sender, EventArgs e)
        {

        }

        private void uxDepGPAButton_Click(object sender, EventArgs e)
        {
            if (uxDepartmentGPA.Text == "")
            {
                MessageBox.Show("Please entere a department id");
            }
            else
            {
                GetDepartmentGrade();
            }
        }

        private void uxTeacherCountButton_Click(object sender, EventArgs e)
        {
            if (uxTeacherCountBox.Text == "")
            {
                MessageBox.Show("Please enter a teacher id");
            }
            else
            {
                uxTeacherCount.Text = (GetTeacherCount().ToString());
            }
        }

        private void uxTeacherGradeButton_Click(object sender, EventArgs e)
        {
            if (uxTeacherGradeBox.Text == "")
            {
                MessageBox.Show("Please entere a teacher id");
            }
            else
            {
                GetTeacherGrade();
            }
        }

        private void uxAddButton_Click(object sender, EventArgs e)
        {
            addStudent = new AddStudent();
            addStudent.ShowDialog();
        }
    }
}
