﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 all grades for a given course
students that have/havent submitted work
average grade for a course
agerage grade for an assignment
given a time frame, get all assignments that got above a certain grade --report
given a student that has a low gpa, calculate how many late assignments they have --report
*/
namespace WindowsFormsApp2
{
    public partial class Teacher : Form
    {
        string id;
        public Teacher(string s)
        {
            id = s;
            InitializeComponent();
        }
    }
}
