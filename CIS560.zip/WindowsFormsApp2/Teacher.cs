﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
/*
 all grades for a given course
students that have/havent submitted work
average grade for a course
agerage grade for an assignment
given a time frame, get all assignments that got above a certain grade --report
given a student that has a low gpa, calculate how many late assignments they have --report
*/
namespace WindowsFormsApp2
{
    public partial class Teacher : Form
    {
        private void GetInfo()
        {
            List<string> test = new List<string>();
            string s = @"Data Source = mssql.cs.ksu.edu; Initial Catalog = justinm1; Integrated Security = True";
            using (SqlConnection Database = new SqlConnection(s))
            {
                using (var command = new SqlCommand("proj4.ReturnInstructor", Database))
                {
                    Database.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("InstructorId", id);

                    var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        uxName.Text = (reader.GetString(reader.GetOrdinal("InstructorName")));
                        uxHours.Text = (reader.GetString(reader.GetOrdinal("OfficeHours")));
                        uxDepartment.Text = (reader.GetInt32(reader.GetOrdinal("DepartmentId")).ToString());
                        uxID.Text = (reader.GetInt32(reader.GetOrdinal("InstructorId")).ToString());
                        uxOffice.Text = ((reader.GetString(reader.GetOrdinal("Office"))));


                    }
                }
            }
        }
        private double GetCourseGrade()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetAverageCourseGrade", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);
                    command.Parameters.AddWithValue("InstructorId", uxID.Text);

                    var reader = command.ExecuteReader();

                    var assignments = new double();
                    while (reader.Read())
                    {

                        assignments = (reader.GetDouble(reader.GetOrdinal("AverageCourseGrade")));
                    }

                    return assignments;
                }
            }
        }
        private List<string> GetCourseGrades()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetStudentsGradesForCourse", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("InstructorId", id);
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);


                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();
                    string one;
                    string two;
                    while (reader.Read())
                    {
                       one=(reader.GetDouble(reader.GetOrdinal("Grade")).ToString());
                        two = reader.GetString(reader.GetOrdinal("Name"));
                        assignments.Add(two + ": " + one +"%");
                    }

                    return assignments;
                }
            }
        }
        private double GetAssignmentGrade()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetAverageAssignmentGrade", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);
                    command.Parameters.AddWithValue("InstructorId", uxID.Text);
                    command.Parameters.AddWithValue("AssignmentId",uxAssignment.Text);
                    var reader = command.ExecuteReader();

                    var assignments = new double();
                    while (reader.Read())
                    {

                        assignments = (reader.GetDouble(reader.GetOrdinal("AverageAssignmentGrade")));
                    }

                    return assignments;
                }
            }
        }
        private List<string> GetAssignmentGrades()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetAssignmentGrades", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("InstructorId", id);
                    command.Parameters.AddWithValue("CourseId", uxCourse.Text);
                    command.Parameters.AddWithValue("AssignmentId", uxAssignment.Text);

                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();
                    string one;
                    string two;
                    while (reader.Read())
                    {
                        one = (reader.GetDouble(reader.GetOrdinal("AssignmentGrade")).ToString());
                        two = reader.GetString(reader.GetOrdinal("Name"));
                        assignments.Add(two + ": " + one + "%");

                    }

                    return assignments;
                }
            }
        }
        private List<string> GetAssignmentTime()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GetAssignmentTimeFrame", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("IID", id);
                    command.Parameters.AddWithValue("Start", uxBefore.Text);
                    command.Parameters.AddWithValue("End", uxAfter.Text);
                    command.Parameters.AddWithValue("Threshold", uxTimeGrade.Text);

                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();
                    string one;
                    string two;
                    while (reader.Read())
                    {
                        assignments.Add(reader.GetInt32(reader.GetOrdinal("SubmissionId")).ToString());
                    }

                    return assignments;
                }
            }
        }
        private List<string> GetAssignmentLate()
        {
            const string connectionString = @"Server=mssql.cs.ksu.edu;Database=justinm1;Integrated Security=SSPI;";
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("proj4.GradeLateAssignments", connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("CAID", uxStudentId.Text);
                    command.Parameters.AddWithValue("Threshold", uxStudentGrade.Text);
                    
                    var reader = command.ExecuteReader();

                    var assignments = new List<string>();
                    string one;
                    string two;
                    while (reader.Read())
                    {
                        assignments.Add(reader.GetInt32(reader.GetOrdinal("LateAssignments")).ToString());
                    }

                    return assignments;
                }
            }
        }
        string id;
        Output o;
        public Teacher(string s)
        {
            id = s;
            InitializeComponent();
            GetInfo();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void uxAVGGradeButton_Click(object sender, EventArgs e)
        {
            if (uxCourse.Text == "")
            {
                MessageBox.Show("Please enter a course ID");
            }
            else
            {
                uxGradeOut.Text = (GetCourseGrade().ToString("#.##")) + "%";
            }
                
        }

        private void uxAllGrades_Click(object sender, EventArgs e)
        {
            if (uxCourse.Text == "")
            {
                MessageBox.Show("Please enter a course ID");
            }
            else
            {
                o = new Output(GetCourseGrades());
                o.ShowDialog();
            }
        }

        private void uxAssignmentGradeButton_Click(object sender, EventArgs e)
        {
            if(uxCourse.Text == "" && uxAssignment.Text == "")
            {
                MessageBox.Show("Please enter a course ID and assignment ID");
            }
            else if (uxCourse.Text == "")
            {
                MessageBox.Show("Please enter a course ID");
            }
            else if (uxAssignment.Text == "")
            {
                MessageBox.Show("Please enter a assignment ID");
            }
            else
            {
                uxAssignmentGrade.Text= (GetAssignmentGrade().ToString("#.##")) + "%";
            }
        }

        private void uxAssigmentGradesButton_Click(object sender, EventArgs e)
        {
            if (uxCourse.Text == "" && uxAssignment.Text == "")
            {
                MessageBox.Show("Please enter a course ID and assignment ID");
            }
            else if (uxCourse.Text == "")
            {
                MessageBox.Show("Please enter a course ID");
            }
            else if (uxAssignment.Text == "")
            {
                MessageBox.Show("Please enter a assignment ID");
            }
            else
            {
                o=new Output(GetAssignmentGrades());
                o.ShowDialog();
            }
        }

        private void uxDateAssignments_Click(object sender, EventArgs e)
        {
            if (uxBefore.Text == ""|| uxAfter.Text == "" || uxTimeGrade.Text == "")
            {
                MessageBox.Show("Please enter all values");
            }
            else
            {
                o = new Output(GetAssignmentTime());
                o.ShowDialog();
            }
        }

        private void uxStudentLate_Click(object sender, EventArgs e)
        {
            if (uxStudentId.Text == "" || uxStudentGrade.Text == "")
            {
                MessageBox.Show("Please enter all values");
            }
            else
            {
                o = new Output(GetAssignmentLate());
                o.ShowDialog();
            }
        }
    }
}
